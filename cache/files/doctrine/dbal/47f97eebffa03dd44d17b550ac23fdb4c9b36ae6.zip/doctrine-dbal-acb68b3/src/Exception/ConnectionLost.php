<?php

declare(strict_types=1);

namespace Doctrine\DBAL\Exception;

final class ConnectionLost extends ConnectionException
{
}
