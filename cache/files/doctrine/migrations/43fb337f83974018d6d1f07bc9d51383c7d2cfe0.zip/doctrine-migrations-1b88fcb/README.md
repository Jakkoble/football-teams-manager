# Doctrine Migrations

[![Build Status](https://github.com/doctrine/migrations/workflows/Continuous%20Integration/badge.svg)](https://github.com/doctrine/migrations/actions)
[![Code Coverage](https://codecov.io/gh/doctrine/migrations/branch/3.1.x/graph/badge.svg)](https://codecov.io/gh/doctrine/migrations/branch/3.1.x)
[![Packagist Downloads](https://img.shields.io/packagist/dm/doctrine/migrations)](https://packagist.org/packages/doctrine/migrations)
[![Packagist Version](https://img.shields.io/packagist/v/doctrine/migrations)](https://packagist.org/packages/doctrine/migrations)
[![GitHub license](https://img.shields.io/github/license/doctrine/migrations)](LICENSE)

## Documentation

All available documentation can be found [here](https://www.doctrine-project.org/projects/migrations.html).
