# Release Notes

Following list includes all available Platform Version release notes:

- [2023.1](./2023.1.md)
- [2023.2](./2023.2.md)
- [2023.3](./2023.3.md)
- [2024.1](./2024.1.md)
- [2024.2](./2024.2.md)
- [2024.3](./2024.3.md)
- [2024.4](./2024.4.md)
- [2025.1](./2025.1.md)
- [2025.2](./2025.2.md)
- [2025.3](./2025.3.md)
