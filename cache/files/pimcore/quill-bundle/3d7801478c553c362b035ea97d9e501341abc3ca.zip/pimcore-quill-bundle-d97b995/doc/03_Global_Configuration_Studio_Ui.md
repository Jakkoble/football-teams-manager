##### Global Configuration (only for studio-ui-bundle)

You can add a Global Configuration with the [symfony config](https://docs.pimcore.com/platform/Studio_UI/Configuration/Wysiwyg) from studio-ui-bundle
