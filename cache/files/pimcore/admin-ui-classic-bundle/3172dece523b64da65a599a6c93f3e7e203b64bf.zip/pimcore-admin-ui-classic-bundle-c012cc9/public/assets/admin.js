import * as L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet-draw";
import "leaflet-draw/dist/leaflet.draw.css";

L.Icon.Default.imagePath = '../bundles/pimcoreadmin/build/admin/images/';
